module.exports = {
  BASE_URL : "http://localhost:5000/",
  API_URL : "http://localhost:5000/api/",
  
};
